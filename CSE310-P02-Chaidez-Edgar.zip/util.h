#ifndef _UTIL_H_
#define _UTIL_H_

#include <iostream>
#include <stdio.h>
using namespace std; 

class Util {

private:
   
public:
    Util(); // Constructor
    int nextCommand(int *s, int *t, int *iFlag);

};

#endif
